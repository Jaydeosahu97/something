package com.shoppingapp.loginAndRegistration.validation;


import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
public class ValidationTest {

	@Test
	public void PasswordValidationtest() {
		assertTrue(UserDetailsValidation.isPasswordValid("Test@1234"));
	}
	@Test
	public void PasswordValidationFailureTest() {
		assertFalse(UserDetailsValidation.isPasswordValid("test"));
	} 
	
	@Test
	public void NullPasswordTest() {
		assertFalse(UserDetailsValidation.isPasswordValid(null));
	}
	
	@Test
	public void PasswordCompareTest() {
		assertTrue(UserDetailsValidation.compareConfirmPasswordAndPasswordFields("Test@1234", "Test@1234"));
	}
	
	@Test
	public void PasswordCompareFailTest() {
		assertFalse(UserDetailsValidation.compareConfirmPasswordAndPasswordFields("Test", null));
	}

}
