package com.shoppingapp.loginAndRegistration;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;

import com.shoppingapp.loginAndRegistration.controller.LoginAndRegistrationController;
import com.shoppingapp.loginAndRegistration.dto.UserDetailsDTO;
import com.shoppingapp.loginAndRegistration.entity.LoginDetails;
import com.shoppingapp.loginAndRegistration.exception.InvalidPasswordException;
import com.shoppingapp.loginAndRegistration.exception.LoginException;
import com.shoppingapp.loginAndRegistration.exception.LoginIdAlreadyExistException;
import com.shoppingapp.loginAndRegistration.response.MessageResponse;
import com.shoppingapp.loginAndRegistration.response.SuccessResponse;
import com.shoppingapp.loginAndRegistration.services.LoginAndRegisterServiceImpl;

@SpringBootTest(classes = LoginAndRegistrationApplicationTests.class)
public class LoginAndRegistrationApplicationTests {
	
	@Mock
	private LoginAndRegisterServiceImpl loginAndRegisterService;
	
	@InjectMocks
	private LoginAndRegistrationController loginAndRegistrationController;
	
	// @Test
	// public void loginTest() throws LoginException {
	// 	LoginDetails loginDetails = new LoginDetails();
	// 	loginDetails.setLoginId("demo");
	// 	loginDetails.setPassword("demo");
	// 	assertNotNull(loginAndRegistrationController.login(loginDetails)); 
	// }
	
	@Test
	public void registerTest() throws InvalidPasswordException, LoginIdAlreadyExistException {
		UserDetailsDTO detailsDTO = new UserDetailsDTO();
//		detailsDTO.setFirstName("Ram");
//		detailsDTO.setLastName("Kumar");
//		detailsDTO.setLoginId("Ram123");
//		detailsDTO.setEmail("ram@ram.com");
//		detailsDTO.setContactNumber("1234567890");
//		detailsDTO.setPassword("ramo");
//		detailsDTO.setConfirmPassword("ramo");
		when(loginAndRegisterService.register(detailsDTO)).thenReturn(new MessageResponse("success", HttpStatus.OK));
		assertNotNull(loginAndRegistrationController.register(detailsDTO));
	}
}
