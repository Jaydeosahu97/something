package com.shoppingapp.loginAndRegistration.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.shoppingapp.loginAndRegistration.dto.UserDetailsDTO;
import com.shoppingapp.loginAndRegistration.entity.UserEntity;
import com.shoppingapp.loginAndRegistration.entity.UserRole;
import com.shoppingapp.loginAndRegistration.exception.InvalidPasswordException;
import com.shoppingapp.loginAndRegistration.exception.LoginIdAlreadyExistException;
import com.shoppingapp.loginAndRegistration.repository.LoginAndRegisterRepository;
import com.shoppingapp.loginAndRegistration.services.LoginAndRegisterServiceImpl;

@SpringBootTest
public class LoginAndRegistrationServiceTest {
	@Mock
	private LoginAndRegisterRepository loginAndRegisterRepository;

	@InjectMocks
	private LoginAndRegisterServiceImpl loginAndRegisterService;

	@Test
	public void loadByUsernameTest() {
		UserEntity user = new UserEntity();
		user.setFirstName("test");
		user.setLastName("test");
		user.setEmail("test@test.com");
		user.setLoginId("test");
		user.setContactNumber("1234567890");
		user.setPassword("Test@1234");
		user.setConfirmPassword("Test@1234");
		Set<UserRole> roles = new HashSet<>();
		roles.add(new UserRole("admin"));
		user.setRoles(roles);
		when(loginAndRegisterRepository.findById(user.getLoginId())).thenReturn(Optional.of(user));
		assertNotNull(loginAndRegisterService.loadUserByUsername(user.getLoginId()));
	}

//	@Test
//	public void loginTest() throws LoginException {
//		Set<GrantedAuthority> authorities = new HashSet<GrantedAuthority>();
//		LoginDetails loginDetails = new LoginDetails();
//		loginDetails.setLoginId("test");
//		loginDetails.setPassword("Test@1234");
//		UserEntity user = new UserEntity();
//		user.setFirstName("test");
//		user.setLastName("test");
//		user.setEmail("test@test.com");
//		user.setLoginId("test");
//		user.setContactNumber("1234567890");
//		user.setPassword("Test@1234");
//		user.setConfirmPassword("Test@1234");
//		Set<UserRole> roles = new HashSet<>();
//		roles.add(new UserRole("admin"));
//		user.setRoles(roles);
//		user.getRoles().stream().forEach(f ->authorities.add(new SimpleGrantedAuthority(f.toString())));
//		when(loginAndRegisterRepository.findById(loginDetails.getLoginId()).get()).thenReturn(user);
//		when(loginAndRegisterService.loadUserByUsername(loginDetails.getLoginId()))
//				.thenReturn(new User(user.getLoginId(), user.getPassword(), authorities));
//		assertNotNull(loginAndRegisterService.login(loginDetails));
//	}

	@Test
	public void registrationTest() throws InvalidPasswordException, LoginIdAlreadyExistException {
		UserDetailsDTO user = new UserDetailsDTO();
		user.setFirstName("test");
		user.setLastName("test");
		user.setEmail("test@test.com");
		user.setLoginId("test");
		user.setContactNumber("1234567890");
		user.setPassword("Test@1234");
		user.setConfirmPassword("Test@1234");
		Set<UserRole> roles = new HashSet<>();
		roles.add(new UserRole("admin"));
		user.setRoles(roles);

		UserEntity userEntity = new UserEntity();
		userEntity.setFirstName(user.getFirstName());
		userEntity.setLastName(user.getLastName());
		userEntity.setLoginId(user.getLoginId());
		userEntity.setEmail(user.getEmail());
		userEntity.setContactNumber(user.getContactNumber());
		userEntity.setPassword(user.getPassword());
		userEntity.setConfirmPassword(user.getConfirmPassword());
		userEntity.setRoles(roles);

		when(loginAndRegisterRepository.findById(user.getLoginId())).thenReturn(Optional.empty());
		when(loginAndRegisterRepository.save(userEntity)).thenReturn(userEntity);
		assertNotNull(loginAndRegisterService.register(user));

	}
}
