package com.shoppingapp.loginAndRegistration.exceptionHandler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.shoppingapp.loginAndRegistration.exception.InvalidPasswordException;
import com.shoppingapp.loginAndRegistration.exception.LoginException;
import com.shoppingapp.loginAndRegistration.exception.LoginIdAlreadyExistException;
import com.shoppingapp.loginAndRegistration.exception.UnauthorizedException;
import com.shoppingapp.loginAndRegistration.response.MessageResponse;

@ControllerAdvice
public class LoginAndRegisterExceptionHandler {

	@ExceptionHandler({LoginException.class,UnauthorizedException.class})
	public ResponseEntity<MessageResponse> loginExceptionHandler(Exception ex) {
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
				.body(new MessageResponse(ex.getMessage(), HttpStatus.UNAUTHORIZED));
	}

	@ExceptionHandler({InvalidPasswordException.class,LoginIdAlreadyExistException.class})
	public ResponseEntity<MessageResponse> invalidInputExceptionHandler(Exception ex) {
		return new ResponseEntity<MessageResponse>(new MessageResponse(ex.getMessage(), HttpStatus.BAD_REQUEST),
				HttpStatus.BAD_REQUEST);
	}
}
