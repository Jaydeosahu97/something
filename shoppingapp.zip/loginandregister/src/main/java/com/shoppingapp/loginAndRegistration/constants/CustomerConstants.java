package com.shoppingapp.loginAndRegistration.constants;

public class CustomerConstants {
	public static final String ADDED_SUCCESSFULLY = "Product added successfully";
	public static final String PRODUCT_ALREADY_EXIST = "Product added successfully";
	public static final String NO_PRODUCT_IN_DATABASE = "No product is their in database";
	public static final String NO_QUERIED_PRODUCT_FOUND = "No product of such query found in the database";
	public static final String INVALID_TOKEN = "Provided token is invalid";
	public static final String PRODUCT_NOT_FOUND = "product not found. please enter correct product id";
	public static final String PRODUCT_OUT_OF_STOCK = "product out of stock. sorry for inconvenience";
	public static final String NO_ORDER_FOUND = "no order found for the current user :)";
}
