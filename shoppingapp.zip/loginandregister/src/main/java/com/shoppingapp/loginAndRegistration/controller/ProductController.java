package com.shoppingapp.loginAndRegistration.controller;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.shoppingapp.loginAndRegistration.constants.ProductOrderConstants;
import com.shoppingapp.loginAndRegistration.dto.ProductDTO;
import com.shoppingapp.loginAndRegistration.exception.InvalidTokenException;
import com.shoppingapp.loginAndRegistration.exception.ProductAlreadyExistException;
import com.shoppingapp.loginAndRegistration.exception.UnauthorizedException;
import com.shoppingapp.loginAndRegistration.exception.WrongProductException;
import com.shoppingapp.loginAndRegistration.response.ExceptionResponse;
import com.shoppingapp.loginAndRegistration.response.ProductCRUDResponse;
import com.shoppingapp.loginAndRegistration.response.SuccessResponse;
import com.shoppingapp.loginAndRegistration.services.LoginAndRegisterService;
import com.shoppingapp.loginAndRegistration.services.ProductService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@CrossOrigin
public class ProductController {

	private ProductService productService;
	private LoginAndRegisterService loginAndRegisterService;

	public ProductController(ProductService productService, LoginAndRegisterService loginAndRegisterService) {
		this.productService = productService;
		this.loginAndRegisterService = loginAndRegisterService;
	}

	@Operation(summary = "This API will add product in the database")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = ProductOrderConstants.ADDED_SUCCESSFULLY, content = @Content(mediaType = "application/json", schema = @Schema(implementation = ProductCRUDResponse.class))),
			@ApiResponse(responseCode = "400", description = ProductOrderConstants.PRODUCT_ALREADY_EXIST, content = @Content(mediaType = "application/json", schema = @Schema(implementation = ExceptionResponse.class))),
			@ApiResponse(responseCode = "403", description = ProductOrderConstants.INVALID_TOKEN_RESPONSE, content = @Content(mediaType = "application/json", schema = @Schema(implementation = ExceptionResponse.class))) })
	@PostMapping("/{productName}/add")
	public ResponseEntity<ProductCRUDResponse> addProduct(@Valid @RequestBody ProductDTO product,
			@PathVariable String productName, @RequestHeader("Authorization") SuccessResponse successResponse)
			throws ProductAlreadyExistException, InvalidTokenException, UnauthorizedException {
		if (!successResponse.getRole().stream().anyMatch(r -> r.equalsIgnoreCase("admin")))
			throw new UnauthorizedException(ProductOrderConstants.FORBIDDEN);
		if (!loginAndRegisterService.validate(successResponse).isValid())
			throw new InvalidTokenException(ProductOrderConstants.INVALID_TOKEN_RESPONSE);
		return ResponseEntity.ok(productService.addProduct(product));
	}

	@Operation(summary = "This API will update product in the database")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = ProductOrderConstants.UPDATED_SUCCESSFULLY, content = @Content(mediaType = "application/json", schema = @Schema(implementation = ProductCRUDResponse.class))),
			@ApiResponse(responseCode = "400", description = ProductOrderConstants.WRONG_PRODUCT_RESPONSE, content = @Content(mediaType = "application/json", schema = @Schema(implementation = ExceptionResponse.class))),
			@ApiResponse(responseCode = "403", description = ProductOrderConstants.INVALID_TOKEN_RESPONSE, content = @Content(mediaType = "application/json", schema = @Schema(implementation = ExceptionResponse.class))) })

	@PutMapping("/{productName}/update/{productId}")
	public ResponseEntity<ProductCRUDResponse> updateProductStatus(
			@RequestHeader("Authorization") SuccessResponse successResponse, @PathVariable String productName,
			@PathVariable String productId, @Valid @RequestBody ProductDTO updatedDetails)
			throws WrongProductException, InvalidTokenException, UnauthorizedException {
		if (!successResponse.getRole().stream().anyMatch(r -> r.equalsIgnoreCase("admin")))
			throw new UnauthorizedException(ProductOrderConstants.FORBIDDEN);
		if (!loginAndRegisterService.validate(successResponse).isValid())
			throw new InvalidTokenException(ProductOrderConstants.INVALID_TOKEN_RESPONSE);
		return ResponseEntity.ok(productService.updateProduct(productName, productId, updatedDetails));
	}

	@DeleteMapping("/{productName}/delete/{productId}")
	public ResponseEntity<ProductCRUDResponse> deleteProduct(
			@RequestHeader("Authorization") SuccessResponse successResponse, @PathVariable String productName,
			@PathVariable String productId) throws InvalidTokenException, UnauthorizedException {
		if (!successResponse.getRole().stream().anyMatch(r -> r.equalsIgnoreCase("admin")))
			throw new UnauthorizedException(ProductOrderConstants.FORBIDDEN);
		if (!loginAndRegisterService.validate(successResponse).isValid())
			throw new InvalidTokenException(ProductOrderConstants.INVALID_TOKEN_RESPONSE);
		return ResponseEntity.ok(productService.deleteProduct(productName, productId));
	}
}
