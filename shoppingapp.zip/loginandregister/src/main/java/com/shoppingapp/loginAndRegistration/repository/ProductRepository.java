package com.shoppingapp.loginAndRegistration.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.shoppingapp.loginAndRegistration.entity.ProductEntity;

public interface ProductRepository extends MongoRepository<ProductEntity, String> {

}
