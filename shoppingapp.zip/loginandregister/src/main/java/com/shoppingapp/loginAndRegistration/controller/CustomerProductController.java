package com.shoppingapp.loginAndRegistration.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shoppingapp.loginAndRegistration.constants.CustomerConstants;
import com.shoppingapp.loginAndRegistration.dto.ProductDTO;
import com.shoppingapp.loginAndRegistration.exception.InvalidTokenException;
import com.shoppingapp.loginAndRegistration.exception.NoProductInDatabaseException;
import com.shoppingapp.loginAndRegistration.exception.UnauthorizedException;
import com.shoppingapp.loginAndRegistration.response.SuccessResponse;
import com.shoppingapp.loginAndRegistration.services.LoginAndRegisterService;
import com.shoppingapp.loginAndRegistration.services.CustomerProductService;

@RestController
@CrossOrigin
public class CustomerProductController {
	private LoginAndRegisterService loginAndRegisterService;
	private CustomerProductService productService;
	
	public CustomerProductController(LoginAndRegisterService loginAndRegisterService,CustomerProductService productService) {
		this.productService = productService;
		this.loginAndRegisterService=loginAndRegisterService;
	}
	
	
	@GetMapping("/all")
	public ResponseEntity<List<ProductDTO>> getAllProduct(@RequestHeader("Authorization") SuccessResponse successResponse) throws NoProductInDatabaseException, InvalidTokenException, UnauthorizedException {
		if(!loginAndRegisterService.validate(successResponse).isValid())
			throw new InvalidTokenException(CustomerConstants.INVALID_TOKEN);
		return ResponseEntity.ok(productService.getAllProducts());
	}
	
	@GetMapping("/products/search/")
	public ResponseEntity<List<ProductDTO>> getProductbyName(@RequestHeader("Authorization") SuccessResponse successResponse,@RequestParam("productname")String productName) throws NoProductInDatabaseException, InvalidTokenException, UnauthorizedException{
		if(!loginAndRegisterService.validate(successResponse).isValid())
			throw new InvalidTokenException(CustomerConstants.INVALID_TOKEN);
		return ResponseEntity.ok(productService.getProductByName(productName));
	}
	
	

}
