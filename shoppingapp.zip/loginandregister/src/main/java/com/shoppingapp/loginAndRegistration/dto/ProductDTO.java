package com.shoppingapp.loginAndRegistration.dto;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@NotBlank
	private String productId;
	@NotBlank
	private String productName;
	@NotBlank
	private String productDescription;
	@Min(value = 0)
	@Digits(fraction = 2, integer = 6)
	private double price;
	@NotEmpty
	private List<String> features;
	@NotBlank
	private String status;
}
