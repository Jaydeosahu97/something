package com.shoppingapp.loginAndRegistration.services;

import java.util.List;

import com.shoppingapp.loginAndRegistration.dto.OrderDTO;
import com.shoppingapp.loginAndRegistration.exception.NoOrderFoundException;
import com.shoppingapp.loginAndRegistration.exception.ProductNotFoundException;
import com.shoppingapp.loginAndRegistration.exception.ProductOutOfStockException;
import com.shoppingapp.loginAndRegistration.request.OrderRequest;

public interface OrderService {
	public OrderDTO createOrder(OrderRequest orderRequest,String username) throws ProductNotFoundException, ProductOutOfStockException;

	public List<OrderDTO> viewOrders(String username) throws NoOrderFoundException;
}
