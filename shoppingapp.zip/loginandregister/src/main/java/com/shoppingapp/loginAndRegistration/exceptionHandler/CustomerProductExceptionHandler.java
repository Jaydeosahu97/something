package com.shoppingapp.loginAndRegistration.exceptionHandler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.shoppingapp.loginAndRegistration.constants.CustomerConstants;
import com.shoppingapp.loginAndRegistration.exception.InvalidTokenException;
import com.shoppingapp.loginAndRegistration.exception.NoOrderFoundException;
import com.shoppingapp.loginAndRegistration.exception.NoProductInDatabaseException;
import com.shoppingapp.loginAndRegistration.exception.ProductAlreadyExistException;
import com.shoppingapp.loginAndRegistration.exception.ProductNotFoundException;
import com.shoppingapp.loginAndRegistration.exception.ProductOutOfStockException;
import com.shoppingapp.loginAndRegistration.response.ExceptionResponse;

@ControllerAdvice
public class CustomerProductExceptionHandler {

	@ExceptionHandler(value = ProductAlreadyExistException.class)
	@ResponseStatus(code = HttpStatus.BAD_REQUEST)
	public ResponseEntity<ExceptionResponse> productExistHandler(Exception exception) {
		return ResponseEntity.badRequest()
				.body(new ExceptionResponse(CustomerConstants.PRODUCT_ALREADY_EXIST, HttpStatus.BAD_REQUEST));
	}

	@ExceptionHandler(value = InvalidTokenException.class)
	@ResponseStatus(code = HttpStatus.FORBIDDEN)
	public ResponseEntity<ExceptionResponse> invalidTokenHandler(Exception exception) {
		return ResponseEntity.badRequest().body(new ExceptionResponse(exception.getMessage(), HttpStatus.FORBIDDEN));
	}

	@ExceptionHandler(value = { NoProductInDatabaseException.class, NoOrderFoundException.class,
			ProductNotFoundException.class, ProductOutOfStockException.class })
	@ResponseStatus(code = HttpStatus.NOT_FOUND)
	public ResponseEntity<ExceptionResponse> notFoundHandler(Exception exception) {
		return ResponseEntity.badRequest().body(new ExceptionResponse(exception.getMessage(), HttpStatus.NOT_FOUND));
	}
}
