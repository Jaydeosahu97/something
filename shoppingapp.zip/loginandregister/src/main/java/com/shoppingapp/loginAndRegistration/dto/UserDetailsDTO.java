package com.shoppingapp.loginAndRegistration.dto;

import java.io.Serializable;
import java.util.Set;

import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

import org.springframework.stereotype.Component;

import com.shoppingapp.loginAndRegistration.entity.UserRole;

import lombok.Data;

@Component
@Data
public class UserDetailsDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1151637347452772181L;
	@NotEmpty(message = "First Name cannot be empty or null")
	private String firstName;
	@NotEmpty(message = "Last Name cannot be empty or null")
	private String lastName;
	@Email(message = "Email should be valid")
	private String email;
	@NotEmpty
	private String loginId;
	@NotEmpty
	private String contactNumber;
	@Min(value = 8,message = "Password should be of length 8 atleast")
	private String password;
	@Min(value = 8,message = "Password should be of length 8 atleast")
	private String confirmPassword;
	@NotEmpty
	private Set<UserRole> roles;
}
