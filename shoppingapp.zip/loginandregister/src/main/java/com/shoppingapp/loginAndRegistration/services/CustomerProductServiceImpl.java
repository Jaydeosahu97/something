package com.shoppingapp.loginAndRegistration.services;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.shoppingapp.loginAndRegistration.constants.CustomerConstants;
import com.shoppingapp.loginAndRegistration.dto.ProductDTO;
import com.shoppingapp.loginAndRegistration.entity.ProductEntity;
import com.shoppingapp.loginAndRegistration.exception.NoProductInDatabaseException;
import com.shoppingapp.loginAndRegistration.repository.CustomerProductRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CustomerProductServiceImpl implements CustomerProductService {
	private CustomerProductRepository productRepository;

	public CustomerProductServiceImpl(CustomerProductRepository productRepository) {
		this.productRepository = productRepository;
	}

	@Override
	public List<ProductDTO> getAllProducts() throws NoProductInDatabaseException {
		String methodName = "getAllProducts()";
		log.info("{} is invoked", methodName);
		List<ProductEntity> products = productRepository.findAll();
		if (products == null) {
			log.info("{} thrown NoProductInDatabaseException()", methodName);
			throw new NoProductInDatabaseException(CustomerConstants.NO_PRODUCT_IN_DATABASE);
		}
		log.info("{} fetched data successfully from database", methodName);
		return products.stream().map(p -> new ProductDTO(p.getProductId(), p.getProductName(),
				p.getProductDescription(), p.getPrice(), p.getFeatures(), p.getStatus())).collect(Collectors.toList());
	}

	@Override
	public List<ProductDTO> getProductByName(String productName) throws NoProductInDatabaseException {
		Optional<List<ProductEntity>> products = productRepository.findByProductName(productName);
		if (products.isEmpty())
			throw new NoProductInDatabaseException(CustomerConstants.NO_QUERIED_PRODUCT_FOUND);
		return products.get().stream().map(p -> new ProductDTO(p.getProductId(), p.getProductName(),
				p.getProductDescription(), p.getPrice(), p.getFeatures(), p.getStatus())).collect(Collectors.toList());

	}

}
