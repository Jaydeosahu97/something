package com.shoppingapp.loginAndRegistration.exceptionHandler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.shoppingapp.loginAndRegistration.exception.InvalidTokenException;
import com.shoppingapp.loginAndRegistration.exception.ProductAlreadyExistException;
import com.shoppingapp.loginAndRegistration.exception.UnauthorizedException;
import com.shoppingapp.loginAndRegistration.exception.WrongProductException;
import com.shoppingapp.loginAndRegistration.response.ExceptionResponse;

@ControllerAdvice
public class ProductExceptionHandler {

	@ResponseStatus(code = HttpStatus.BAD_REQUEST)
	@ExceptionHandler(value = { ProductAlreadyExistException.class, WrongProductException.class })
	protected ResponseEntity<ExceptionResponse> productExistHandler(Exception exception) {
		return ResponseEntity.badRequest().body(
				ExceptionResponse.builder().message(exception.getMessage()).statusCode(HttpStatus.BAD_REQUEST).build());
	}

	@ResponseStatus(code = HttpStatus.FORBIDDEN)
	@ExceptionHandler(value = { InvalidTokenException.class, UnauthorizedException.class })
	protected ResponseEntity<ExceptionResponse> invalidTokenHandler(Exception ex) {
		return ResponseEntity.status(HttpStatus.FORBIDDEN)
				.body(ExceptionResponse.builder().message(ex.getMessage()).statusCode(HttpStatus.FORBIDDEN).build());
	}
}
