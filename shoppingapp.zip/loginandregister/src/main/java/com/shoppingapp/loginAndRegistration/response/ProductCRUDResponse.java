package com.shoppingapp.loginAndRegistration.response;

import org.springframework.http.HttpStatus;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class ProductCRUDResponse {
	private String message;
	private HttpStatus statusCode;
}
