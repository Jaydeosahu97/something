package com.shoppingapp.loginAndRegistration.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.shoppingapp.loginAndRegistration.constants.CustomerConstants;
import com.shoppingapp.loginAndRegistration.dto.OrderDTO;
import com.shoppingapp.loginAndRegistration.exception.InvalidTokenException;
import com.shoppingapp.loginAndRegistration.exception.NoOrderFoundException;
import com.shoppingapp.loginAndRegistration.exception.ProductNotFoundException;
import com.shoppingapp.loginAndRegistration.exception.ProductOutOfStockException;
import com.shoppingapp.loginAndRegistration.exception.UnauthorizedException;
import com.shoppingapp.loginAndRegistration.request.OrderRequest;
import com.shoppingapp.loginAndRegistration.response.AuthResponse;
import com.shoppingapp.loginAndRegistration.response.SuccessResponse;
import com.shoppingapp.loginAndRegistration.services.LoginAndRegisterService;
import com.shoppingapp.loginAndRegistration.services.OrderService;

@RestController
@CrossOrigin
public class OrderController {
	@Autowired
	private LoginAndRegisterService loginAndRegisterService;
	@Autowired
	private OrderService orderService;

	@PostMapping("/order")
	public ResponseEntity<OrderDTO> createOrder(@RequestHeader("Authorization") SuccessResponse successResponse,@RequestBody OrderRequest orderRequest) throws InvalidTokenException, ProductNotFoundException, ProductOutOfStockException, UnauthorizedException{
		AuthResponse user = loginAndRegisterService.validate(successResponse);
		if(!user.isValid())
			throw new InvalidTokenException(CustomerConstants.INVALID_TOKEN);
		return ResponseEntity.ok(orderService.createOrder(orderRequest,user.getUsername()));
		}
	
	@GetMapping("/view/order")	
	public ResponseEntity<List<OrderDTO>> viewOrders(@RequestHeader("Authorization") SuccessResponse successResponse) throws InvalidTokenException, NoOrderFoundException, UnauthorizedException{
		AuthResponse user = loginAndRegisterService.validate(successResponse);
		if(!user.isValid())
			throw new InvalidTokenException(CustomerConstants.INVALID_TOKEN);	
		return ResponseEntity.ok(orderService.viewOrders(user.getUsername()));
	}
}
