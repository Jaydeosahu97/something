package com.shoppingapp.loginAndRegistration.constants;

public class ProductOrderConstants {
	public static final String ADDED_SUCCESSFULLY = "Product added successfully";
	public static final String UPDATED_SUCCESSFULLY = "Product updated successfully";
	public static final String PRODUCT_ALREADY_EXIST = "Product added successfully";
	public static final String WRONG_PRODUCT_RESPONSE = "trying to add wrong product than mentioned. Please try enter correct product details";
	public static final String NO_ELEMENT_FOUND_RESPONSE = "The entered product id you are trying to update is not in database";
	public static final String INVALID_TOKEN_RESPONSE = "Invalid token passed or token invalidated";
	public static final String PRODUCT_DELETED_SUCCESSFULLY = "product deleted successfully";
	public static final String FORBIDDEN = "user not allowed to access";
	
}
