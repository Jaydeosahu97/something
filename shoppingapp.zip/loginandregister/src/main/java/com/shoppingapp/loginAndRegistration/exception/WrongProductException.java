package com.shoppingapp.loginAndRegistration.exception;

public class WrongProductException extends Exception {
	private static final long serialVersionUID = 1L;

	public WrongProductException(String message) {
		super(message);
	}
}
