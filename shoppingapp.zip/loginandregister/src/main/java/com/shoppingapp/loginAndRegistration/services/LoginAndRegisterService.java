package com.shoppingapp.loginAndRegistration.services;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.shoppingapp.loginAndRegistration.dto.UserDetailsDTO;
import com.shoppingapp.loginAndRegistration.exception.InvalidPasswordException;
import com.shoppingapp.loginAndRegistration.exception.InvalidTokenException;
import com.shoppingapp.loginAndRegistration.exception.LoginIdAlreadyExistException;
import com.shoppingapp.loginAndRegistration.exception.UnauthorizedException;
import com.shoppingapp.loginAndRegistration.response.AuthResponse;
import com.shoppingapp.loginAndRegistration.response.MessageResponse;
import com.shoppingapp.loginAndRegistration.response.SuccessResponse;

public interface LoginAndRegisterService extends UserDetailsService {

	public MessageResponse register(UserDetailsDTO userDetails)
			throws InvalidPasswordException, LoginIdAlreadyExistException;
	
	public AuthResponse validate(SuccessResponse successResponse) throws InvalidTokenException, UnauthorizedException;
	
	public MessageResponse forgotPassword(String customerName,String token,String password);

	
	
}
