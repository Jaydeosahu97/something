package com.shoppingapp.loginAndRegistration.services;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.shoppingapp.loginAndRegistration.constants.CustomerConstants;
import com.shoppingapp.loginAndRegistration.dto.OrderDTO;
import com.shoppingapp.loginAndRegistration.entity.OrderEntity;
import com.shoppingapp.loginAndRegistration.entity.ProductEntity;
import com.shoppingapp.loginAndRegistration.exception.NoOrderFoundException;
import com.shoppingapp.loginAndRegistration.exception.ProductNotFoundException;
import com.shoppingapp.loginAndRegistration.exception.ProductOutOfStockException;
import com.shoppingapp.loginAndRegistration.repository.OrderRepository;
import com.shoppingapp.loginAndRegistration.repository.CustomerProductRepository;
import com.shoppingapp.loginAndRegistration.request.OrderRequest;

@Service
public class OrderServiceImpl implements OrderService {

	private CustomerProductRepository productRepository;
	private OrderRepository orderRepository;

	public OrderServiceImpl(CustomerProductRepository productRepository, OrderRepository orderRepository) {
		this.productRepository = productRepository;
		this.orderRepository = orderRepository;
	}

	@Override
	public OrderDTO createOrder(OrderRequest orderRequest, String username)
			throws ProductNotFoundException, ProductOutOfStockException {
		Optional<ProductEntity> productEntity = productRepository.findById(orderRequest.getProductId());
		if (productEntity.isEmpty())
			throw new ProductNotFoundException(CustomerConstants.PRODUCT_NOT_FOUND);
		if (productEntity.get().getStatus().equalsIgnoreCase("out of stock"))
			throw new ProductOutOfStockException(CustomerConstants.PRODUCT_OUT_OF_STOCK);
		OrderEntity orderEntity = new OrderEntity();
		orderEntity.setProductId(productEntity.get().getProductId());
		orderEntity.setProductName(productEntity.get().getProductName());
		orderEntity.setQuantity(orderRequest.getQuantity());
		orderEntity.setUsername(username);
		OrderEntity savedEntity = orderRepository.save(orderEntity);
		OrderDTO orderDTO = new OrderDTO();
		orderDTO.set_id(savedEntity.get_id().toHexString());
		orderDTO.setProductId(savedEntity.getProductId());
		orderDTO.setProductName(savedEntity.getProductName());
		orderDTO.setQuantity(savedEntity.getQuantity());
		orderDTO.setUsername(savedEntity.getUsername());
		return orderDTO;
	}

	@Override
	public List<OrderDTO> viewOrders(String username) throws NoOrderFoundException {
		Optional<List<OrderEntity>> orders = orderRepository.findByUsername(username);
		if (orders.isEmpty())
			throw new NoOrderFoundException(CustomerConstants.NO_ORDER_FOUND);
		List<OrderDTO> ordersDTOList = orders.get().stream().map(o -> new OrderDTO(o.get_id().toHexString(),
				o.getProductId(), o.getProductName(), o.getQuantity(), o.getUsername())).collect(Collectors.toList());
		return ordersDTOList;
	}

}
