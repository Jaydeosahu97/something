package com.shoppingapp.loginAndRegistration.services;

import com.shoppingapp.loginAndRegistration.dto.ProductDTO;
import com.shoppingapp.loginAndRegistration.exception.ProductAlreadyExistException;
import com.shoppingapp.loginAndRegistration.exception.WrongProductException;
import com.shoppingapp.loginAndRegistration.response.ProductCRUDResponse;

public interface ProductService {	
	public ProductCRUDResponse addProduct(ProductDTO product) throws ProductAlreadyExistException;

	public ProductCRUDResponse updateProduct(String productName, String productId, ProductDTO updatedDetails) throws WrongProductException;

	public ProductCRUDResponse deleteProduct(String productName, String productId);
}
