package com.shoppingapp.loginAndRegistration.exception;

public class NoProductInDatabaseException extends Exception {

	private static final long serialVersionUID = 1L;

	public NoProductInDatabaseException(String message) {
		super(message);
	}

}
