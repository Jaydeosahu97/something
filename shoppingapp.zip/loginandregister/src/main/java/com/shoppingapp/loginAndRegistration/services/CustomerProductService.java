package com.shoppingapp.loginAndRegistration.services;

import java.util.List;

import com.shoppingapp.loginAndRegistration.dto.ProductDTO;
import com.shoppingapp.loginAndRegistration.exception.NoProductInDatabaseException;

public interface CustomerProductService {
	public List<ProductDTO> getAllProducts() throws NoProductInDatabaseException;

	public List<ProductDTO> getProductByName(String productName) throws NoProductInDatabaseException;
}
 