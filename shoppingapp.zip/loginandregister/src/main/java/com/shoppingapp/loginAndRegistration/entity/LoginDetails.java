package com.shoppingapp.loginAndRegistration.entity;

import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class LoginDetails {
	@NotNull
	private String loginId;
	@NotNull
	private String password;
}
