package com.shoppingapp.loginAndRegistration.entity;

import java.util.Set;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;
@Data
@Document(collection = "users")
public class UserEntity {
	@Id
	private String loginId;
	private String firstName;
	private String lastName;
	@Indexed(unique = true)
	private String email;
	private String contactNumber;
	private String password;
	private String confirmPassword;
	private Set<UserRole> roles;
}
