package com.shoppingapp.loginAndRegistration.services;

import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.shoppingapp.loginAndRegistration.constants.ProductOrderConstants;
import com.shoppingapp.loginAndRegistration.dto.ProductDTO;
import com.shoppingapp.loginAndRegistration.entity.ProductEntity;
import com.shoppingapp.loginAndRegistration.exception.ProductAlreadyExistException;
import com.shoppingapp.loginAndRegistration.exception.WrongProductException;
import com.shoppingapp.loginAndRegistration.repository.ProductRepository;
import com.shoppingapp.loginAndRegistration.response.ProductCRUDResponse;

@Service
public class ProductServiceImpl implements ProductService {

	private ProductRepository productRepository;

	public ProductServiceImpl(ProductRepository productRepository) {
		this.productRepository = productRepository;
	}

	@Override
	public ProductCRUDResponse addProduct(ProductDTO product) throws ProductAlreadyExistException {
		if (productRepository.findById(product.getProductId()).isPresent())
			throw new ProductAlreadyExistException("Cannot Add Product. It already Exist");
		ProductEntity productEntity = new ProductEntity();
		productEntity.setProductName(product.getProductName());
		productEntity.setProductDescription(product.getProductDescription());
		productEntity.setPrice(product.getPrice());
		productEntity.setStatus(product.getStatus());
		productEntity.setFeatures(product.getFeatures());
		productEntity.setProductId(product.getProductId());
		productRepository.save(productEntity);
		return new ProductCRUDResponse("Product added successfully", HttpStatus.OK);
	}

	@Override
	public ProductCRUDResponse updateProduct(String productName, String productId, ProductDTO updatedDetails) throws WrongProductException,NoSuchElementException {
		System.out.println(productName+ "---"+updatedDetails.getProductName());
		if(!productName.equalsIgnoreCase(updatedDetails.getProductName()))
			throw new WrongProductException(ProductOrderConstants.WRONG_PRODUCT_RESPONSE);
		Optional<ProductEntity> product = productRepository.findById(productId);
		if(product.isEmpty())
			throw new NoSuchElementException(ProductOrderConstants.NO_ELEMENT_FOUND_RESPONSE);
		//TODO Validations need to be done from here onwards
		ProductEntity productEntity = product.get();
		productEntity.setProductName(updatedDetails.getProductName());
		productEntity.setProductDescription(updatedDetails.getProductDescription());
		productEntity.setPrice(updatedDetails.getPrice());
		productEntity.setFeatures(updatedDetails.getFeatures());
		productEntity.setStatus(updatedDetails.getStatus());
		productRepository.save(productEntity);
		return new ProductCRUDResponse(ProductOrderConstants.UPDATED_SUCCESSFULLY, HttpStatus.OK);
	}

	@Override
	public ProductCRUDResponse deleteProduct(String productName, String productId) {
		productRepository.deleteById(productId);
		return new ProductCRUDResponse(ProductOrderConstants.PRODUCT_DELETED_SUCCESSFULLY, HttpStatus.OK);
	}

}
