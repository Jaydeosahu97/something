package com.shoppingapp.loginAndRegistration.controller;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.shoppingapp.loginAndRegistration.response.SuccessResponse;

@Component
public class HeaderConverter implements Converter<String, SuccessResponse> {

	@Override
	public SuccessResponse convert(String source) {
		// TODO Auto-generated method stub
		ObjectMapper om = new ObjectMapper();
		SuccessResponse successResponse=null;
		try {
			successResponse = om.readValue(source, SuccessResponse.class);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return successResponse;
	}

}
