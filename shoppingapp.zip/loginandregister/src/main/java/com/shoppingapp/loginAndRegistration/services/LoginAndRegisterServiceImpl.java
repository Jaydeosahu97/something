package com.shoppingapp.loginAndRegistration.services;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.shoppingapp.loginAndRegistration.dto.UserDetailsDTO;
import com.shoppingapp.loginAndRegistration.entity.UserEntity;
import com.shoppingapp.loginAndRegistration.entity.UserRole;
import com.shoppingapp.loginAndRegistration.exception.InvalidPasswordException;
import com.shoppingapp.loginAndRegistration.exception.InvalidTokenException;
import com.shoppingapp.loginAndRegistration.exception.LoginIdAlreadyExistException;
import com.shoppingapp.loginAndRegistration.exception.UnauthorizedException;
import com.shoppingapp.loginAndRegistration.jwt.JwtUtil;
import com.shoppingapp.loginAndRegistration.repository.LoginAndRegisterRepository;
import com.shoppingapp.loginAndRegistration.response.AuthResponse;
import com.shoppingapp.loginAndRegistration.response.MessageResponse;
import com.shoppingapp.loginAndRegistration.response.SuccessResponse;
import com.shoppingapp.loginAndRegistration.validation.UserDetailsValidation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class LoginAndRegisterServiceImpl implements LoginAndRegisterService {

	private LoginAndRegisterRepository loginAndRegisterRepository;
	private JwtUtil jwtUtil;

	public LoginAndRegisterServiceImpl(LoginAndRegisterRepository loginAndRegisterRepository, JwtUtil jwtUtil) {
		this.loginAndRegisterRepository = loginAndRegisterRepository;
		this.jwtUtil = jwtUtil;
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		String methodName = "loadUserByUsername()";
		log.info("{} invoked", methodName);
		UserEntity user = loginAndRegisterRepository.findById(username).get();
		Set<GrantedAuthority> grantedAuthorities = new HashSet<>();

		user.getRoles().forEach(role -> grantedAuthorities.add(new SimpleGrantedAuthority(role.getAuthority())));
		return new User(user.getLoginId(), user.getPassword(), grantedAuthorities);
	}

	@Override
	public MessageResponse register(@Valid UserDetailsDTO userDetails)
			throws InvalidPasswordException, LoginIdAlreadyExistException {

		Optional<UserEntity> existingUser = loginAndRegisterRepository.findById(userDetails.getLoginId());
		if (existingUser.isPresent()) {
			throw new LoginIdAlreadyExistException("login ID already taken");
		}
		String methodName = "register()";
		log.info("{} invoked: ", methodName);
		if (!UserDetailsValidation.isPasswordValid(userDetails.getPassword())) {
			log.info("Inside {} . Password validation failed ");
			throw new InvalidPasswordException(
					"Password should have atleast 1 lowercase, uppercase, special character");
		}

		if (!UserDetailsValidation.compareConfirmPasswordAndPasswordFields(userDetails.getPassword(),
				userDetails.getConfirmPassword())) {
			log.info("Inside {} . 'confirmPassword' and 'Password' validation failed ", methodName);
			throw new InvalidPasswordException("Please enter the same password in both fields");
		}

		UserEntity userEntity = new UserEntity();
		userEntity.setFirstName(userDetails.getFirstName());
		userEntity.setLastName(userDetails.getLastName());
		userEntity.setEmail(userDetails.getEmail());
		userEntity.setLoginId(userDetails.getLoginId());
		userEntity.setPassword(userDetails.getPassword());
		userEntity.setConfirmPassword(userDetails.getConfirmPassword());
		userEntity.setContactNumber(userDetails.getContactNumber());
		userEntity.setRoles(userDetails.getRoles());
		loginAndRegisterRepository.save(userEntity);
		return new MessageResponse("User Registered Successfully", HttpStatus.OK);
	}

	@Override
	public AuthResponse validate(SuccessResponse successResponse) throws InvalidTokenException, UnauthorizedException {
		Set<UserRole> roles = loginAndRegisterRepository.findById(successResponse.getLoginId()).get().getRoles();

		if (!successResponse.getRole().stream()
				.anyMatch(r -> roles.stream().anyMatch(t -> r.equalsIgnoreCase(t.getAuthority())))) {
			throw new InvalidTokenException("user is not authorized to access");
		}
			if (!jwtUtil.validateToken(successResponse.getToken()))
				throw new InvalidTokenException("Invalid Token");
			log.info("User validated successfully");
		return new AuthResponse(jwtUtil.extractUsername(successResponse.getToken()),
				jwtUtil.validateToken(successResponse.getToken()));
	}

	@Override
	public MessageResponse forgotPassword(String customerName, String token, String password) {

		UserEntity userEntity = loginAndRegisterRepository.findByFirstName(customerName).get().stream()
				.filter(f -> f.getLoginId().equals(jwtUtil.extractUsername(token))).findFirst().get();
		userEntity.setPassword(password);
		loginAndRegisterRepository.save(userEntity);
		return new MessageResponse("password updated successfully", HttpStatus.OK);

	}

}
