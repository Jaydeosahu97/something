package com.shoppingapp.loginAndRegistration.repository;

import java.util.List;
import java.util.Optional;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.shoppingapp.loginAndRegistration.entity.OrderEntity;
@Repository
public interface OrderRepository extends MongoRepository<OrderEntity, ObjectId> {
	
	Optional<List<OrderEntity>> findByUsername(String username);

}
