package com.shoppingapp.loginAndRegistration.request;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class OrderRequest {
	
	private String productId;
	private Integer quantity;
	
	public OrderRequest() {
		// TODO Auto-generated constructor stub
	}

}
