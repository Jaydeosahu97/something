package com.shoppingapp.loginAndRegistration.request;

import org.springframework.stereotype.Component;

@Component
public class AuthRequest {
	String token;
	String role;

}
