package com.shoppingapp.loginAndRegistration.exception;

public class LoginException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LoginException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
